<?php
/*
 Plugin Name: Production Testrecord Dashboard
 Plugin URI: http://diagnostic09:8080/wordpress/
 Description: Display production test records.
 Version: 1.0
 Author: ASM HK Co. Diagnostic & Testing Team
 Author URI: http://diagnostic09:8080/wordpress/
 Text Domain: Production Testrecord
----------------------------------------------------------------------
Copyright 2016 ASM HongKong Ltd.

*/
define( 'Dashboard_PATH', plugin_dir_path(__FILE__) ); 
define('Dashboard_URL', plugins_url( '/', __FILE__ ));

function dwwp_add_menu_page(){
	$current_role = Dashboardbase::get_current_user_role();
	add_menu_page(
	'Production records', 
	'Production Testrecord', 
	'manage_options',
	'ProductionDashboard',
	'ProductionDashboard-custom',
	'',
	29);
	add_submenu_page(
	'ProductionDashboard',
	'Email',
	'Email',
	'manage_options',
	'ProductionDashboard',
	'loadEmailPage'
	);
	add_submenu_page(
	'ProductionDashboard',
	'Setting',
	'Setting',
	$current_role,
	'Setting',
	'loadSettingPage'
	);
	add_submenu_page(
	'ProductionDashboard',
	'PassingRate',
	'PassingRate',
	'manage_options',
	'Connection',
	'loadPassingRate'
	);
	add_submenu_page(
	'ProductionDashboard',
	'Dashboard',
	'Dashboard',
	$current_role,
	'Dashboard',
	'loadDashboardPage'
	);
	add_submenu_page(
	'ProductionDashboard',
	'LineChart',
	'LineChart',
	'manage_options',
	'LineChart',
	'loadLineChart'
	);
	/* wp_enqueue_script('Dashboard',
							   Dashboard_URL. 'js/pages/Dashboard.js',
							   array(),
							   null,
							   true); */
							   
	/* wp_enqueue_script('PassingRate',
							   Dashboard_URL. 'js/pages/PassingRate.js',
							   array(),
							   null,
							   true); */						
	wp_enqueue_script( 'jquery-ui-core' ) ;
	wp_enqueue_script( 'jquery-ui-widget' ) ;
	wp_enqueue_script( 'jquery-ui-mouse' ) ;
	wp_enqueue_script( 'jquery-ui-sortable' ) ;
	wp_enqueue_script( 'jquery-ui-datepicker' ) ;
	
	wp_enqueue_script( 'jquery-json',
					   Dashboard_URL. 'js/lib/jquery.json.js',
					   '',
					   '2.3',
					   true);
	
	wp_enqueue_script( 'jquery-ui-draggable' ) ;
	wp_enqueue_script( 'jquery-ui-droppable' ) ;
	wp_enqueue_script( 'jsPlumb',
   		                   Dashboard_URL. 'js/lib/jquery.jsPlumb-all-min.js',
   		                   array('jquery-ui-core', 'jquery-ui-draggable', 'jquery-ui-droppable'),
   		                   '1.4.1',
   		                   true);
	wp_enqueue_script( 'dashboard-underscore',
   		                   Dashboard_URL. 'js/lib/underscore.js',
   		                   '',
   		                   '1.4.4',
   		                   true);
	wp_enqueue_script( 'jquery-simplemodal',
   		                   Dashboard_URL. 'js/lib/modal/jquery.simplemodal.js',
   		                   '',
   		                   '1.4.5',
   		                   true);
					   
	wp_enqueue_script( 'dashboard-sort',
   		                   Dashboard_URL. 'js/lib/Sortable.js',
   		                   '',
   		                   '1.0',
   		                   true);
						   
	wp_enqueue_script( 'dashboard-sortElement',
					   Dashboard_URL. 'js/lib/jquery.sortElements.js',
					   '',
					   '1.0',
					   true);						   
	wp_enqueue_style( 'owf-calendar-css',
      	                   Dashboard_URL. 'css/lib/calendar/datepicker.css',
      	                   false,
      	                   '1.0',
                            'all');				  
}

function loadDashboardPage(){
	include( Dashboard_PATH . "/includes/pages/Setting - BK.php" ) ;
}	
function loadSettingPage(){
	include( Dashboard_PATH . "/includes/pages/Setting.php" ) ;
}
function loadPassingRate(){
	include( Dashboard_PATH . "/includes/pages/PassingRate.php" ) ;
}
function loadEmailPage(){
	include( Dashboard_PATH . "/includes/pages/Email.php" ) ;
}
function loadLineChart(){
	include( Dashboard_PATH . "/includes/pages/Neng.php" ) ;
}

include( Dashboard_PATH . "/includes/Dashboard.php" );
$dashboardbase = new Dashboardbase();

add_action('admin_menu', 'dwwp_add_menu_page');
add_action('wp_ajax_get_testitems_of_partno', array( 'Dashboardbase', 'get_testitems_of_partno' ));
add_action('wp_ajax_get_production_testrecords', array( 'Dashboardbase', 'get_production_testrecords' ));
add_action('wp_ajax_get1stPassingRate', array( 'Dashboardbase', 'get1stPassingRate' ));
add_action('wp_ajax_get_current_user_role', array( 'Dashboardbase', 'get_current_user_role' ));
add_action('wp_ajax_get_testitemStatistics', array( 'Dashboardbase', 'get_testitemStatistics' ));
add_action('wp_ajax_get_attribute1_of_testitem', array( 'Dashboardbase', 'get_attribute1_of_testitem' ));
add_action('wp_ajax_get_attribute2info_of_testitem', array( 'Dashboardbase', 'get_attribute2info_of_testitem' ));
add_action('wp_ajax_get_testresultdata', array( 'Dashboardbase', 'get_testresultdata' ));
add_action('wp_ajax_getDescription', array( 'Dashboardbase', 'getDescription' ));
add_action('wp_ajax_get_testresultStatisticsSummary', array( 'Dashboardbase', 'get_testresultStatisticsSummary' ));
?>
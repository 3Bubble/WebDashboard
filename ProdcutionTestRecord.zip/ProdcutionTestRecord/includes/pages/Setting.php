<?php
	 	$partNoList = Dashboardbase::getPartNoList(wp_get_current_user()->user_login);
		$availableTags = "";
		foreach($partNoList as $pn)
		{
			$descript = Dashboardbase::getDescription($pn);
			$availableTags .= "'".$pn.", ".$descript."',";
		}
		$availableTags = "[".$availableTags."]";
		
		wp_enqueue_script( 'dashboard-charts_loader',
   		                   Dashboard_URL. 'js/lib/charts_loader.js',
   		                   '',
   		                   '1.0',
   		                   true);
		wp_enqueue_script('Setting',
							   Dashboard_URL. 'js/pages/Setting.js',
							   array(),
							   null,
							   true);
		
		wp_enqueue_script('jquery.dataTables.min',
							   Dashboard_URL. 'js/lib/jquery.dataTables.min.js',
							   array(),
							   null,
							   true);
		wp_enqueue_style( 'jquery.dataTables.min.style',
      	                   Dashboard_URL. 'css/lib/jquery.dataTables.min.css',
      	                   false,
      	                   '1.0',
                            'all');
		wp_enqueue_script('jquery.table2excel',
							   Dashboard_URL. 'js/lib/jquery.table2excel.js',
							   array(),
							   null,
							   true);
	?>
<html lang="en">
<head>
	<meta charset="utf-8" http-equiv="X-UA-Compatible" content="IE-Edge">
	<link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
	<script src="//code.jquery.com/jquery-1.10.2.js"></script>
	<script src= "http://www.cloudformatter.com/Resources/Pages/CSS2Pdf/Script/xepOnline.jqPlugin.js"></script>
	<script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	<style>
	 .ui-autocomplete {
			max-height: 200px;
			overflow-y: auto;
			/* prevent horizontal scrollbar */
			overflow-x: hidden;
		}
	 html .ui-autocomplete {
			height: 200px;
		}
	 </style>
	  <script>
	 $(function() {
    var availableTags = <?php echo $availableTags; ?>;
		$("#setting-partno_select").autocomplete({
			source:availableTags
		});
	 });
	 </script>
</head>
<div id="loader" style="position:absolute;top:50%;left:50%;width:100%;height:100%;">
	<img src="http://diagnostic09:8080/wordpress/wp-content/plugins/ProdcutionTestRecord/css/images/image-loader.gif" style="" />
</div>
<div id="webContent" style="display:none">
<h1 style = "font-family:Arial;font-weight:bold;">Test Result Billboard</h1>
<hr style="width:100%;margin-top:20px;margin-bottom:10px;">
<div>

<div style="width:100%;">
<table style='float:right;margin:0px;'>
	<thead >
		<tr>
			<th><a><span style="cursor:text;color:#464646;">START DATE</span></a></th>
			<th><a><span style="cursor:text;color:#464646;">END DATE</span></a></th>
		</tr>
		<tr>
			<td>
				<input name="setting-start-date" id="setting-start-date" class="date_input" type="text" real="publish-date-loading-span" value="" ></input>
			</td>
			<td>
				<input name="setting-end-date" id="setting-end-date" class="date_input" type="text" real="publish-date-loading-span" value="" />
			</td>
		</tr>
		<tr>
		<td ></td>
			<td style='float:right;'>
			<input id="allresultRefresh" type='button' value="Refresh" style='font-Size:11px;'   />
			</td>
		</tr>
	</thead>
	
</table>


<table style='width:240px;float:left; height:50px;border-collapse:collapse;margin:10px;font-size:12px;border:1px solid black;' >
	<thead style='background-color:#464646;'>
		<tr>
		<th><h2 style="color:white;">PartNo</h2></th>
		</tr>
	</thead>
	<tbody  style='font-size:15px;text-align:center;'>
		<tr id="partnoListInfo">
			<td >
			<input id='setting-partno_select' style='width:200px;' />
			
<?php
	  echo <<<ADD_BLANK_OPTION
		<script>
		   jQuery(document).ready(function() {
			  jQuery('#setting-partno_select').prepend('<option selected="selected"></option>');
		   });
		</script>
ADD_BLANK_OPTION;
?>
			</td>
		</tr>
	</tbody>
	
</table>
	
<table style='width:240px;float:left;  height:50px;border-collapse:collapse;margin:9px;font-size:12px;border:1px solid black' >
			<thead style='background-color:#464646;'>
				<tr>
				<th><h2 style="color:white;">TestItem</h2></th>
				</tr>
			</thead>
			<tbody style='font-size:15px;text-align:center;'>
				<tr >
					<td ><select id='setting-testitem_select' style='width:200px;'></select></td>
				</tr>
			</tbody>
</table>

<hr class="separator" style="width:100%;margin-top:40px;margin-bottom:20px;">

<table id = 'setting-passingrate-table' style='width:100%;'/>
<div id='setting_chart_div' style='width:100%;'></div>	
</div>
<hr class="separator" style="width:100%;margin-top:10px;margin-bottom:20px;">
<input id = "hideButton_testrecords" type ="button" value="Hide/Show Table" style="font-size:10px;" />
<button class="export2excel" onclick="jQuery('#setting-production_testrecords').table2excel({exclude: '.wp-list-table widefat fixed posts',name: 'TestRocord',filename: 'TestRocord'});" >Excel</button>
<table class="wp-list-table widefat fixed posts" id="setting-production_testrecords" style="width:100%;" cellspacing="0">
	<thead >
		<tr >
			<th id="sort-action-name" class="sortable desc"  ><a><span style="color:white;">Datetime</span></a></th>
			<th id="sort-action-name" class="sortable desc" ><a><span style="color:white;">SerialNo</span></a></th>
			<th id="sort-action-name" class="sortable desc"  ><a><span style="color:white;">Status</span></a></th>
			<th id="sort-action-name" class="sortable desc" ><a><span style="color:white;">Report</span></a></th>
		</tr>
	</thead>
	<tbody id ="setting-production_testrecords_body" ></tbody>
</table>
<hr class="separator" style="width:100%;">
<table id="attributesFilter" style="font-size:8px;page-break-inside:auto;">
	<tr id= "attributesHeader" style ="page-break-inside:avoid; page-break-after:auto;">
		<th><h2>Attribute 1</h2></th>
		<td>
			<select id='lineChart_attribute1_select' style='width:120px;font-size:12px;' >
			</select>
		</td>
		<th id= "attributes2Header"><h2>Attribute 2</h2></th>
		<td id= "attributes2Content">
			<select id='lineChart_attribute2_select' style='width:120px;font-size:12px;' >
			</select>
		</td>
	</tr>
	
</table>

<input id = "hideButton" type ="button" value="Hide/Show Table"  style="font-size:10px;" />
<Button class="export2excel" onclick="jQuery('#lineChart_production_testrecords').table2excel({exclude: '.wp-list-table widefat fixed posts',name: 'TestResult',filename: 'TestResult'});" >Excel</Button>
<table class="wp-list-table widefat fixed posts" id="lineChart_production_testrecords" style='width:100%;' cellspacing="0"  >
	<thead >
		<tr >
			<th id="sort-action-record" class="sortable desc"><a><span style="color:white;">Datetime</span></a></th>
			<th id="sort-action-record" class="sortable desc" ><a href="#" data-toggle="tooltip" data-placement="right" title="Lower limit value"><span style="color:white;">LL</span></a></th>
			<th id="sort-action-record" class="sortable desc"><a  href="#" data-toggle="tooltip" data-placement="right" title="Test result data value"><span style="color:white;">Data</span></a></th>
			<th id="sort-action-record" class="sortable desc"><a  href="#" data-toggle="tooltip" data-placement="right" title="Upper limit value"><span style="color:white;">UL</span></a></th>
			<th id="sort-action-record" class="sortable desc"><a><span style="color:white;">Result</span></a></th>
		</tr>
	</thead>
	<tbody id = "lineChart_production_testrecords_body">
	</tbody>
</table>

<hr class="separator" style="width:100%;">
<input id= "refreshLine" type="button" value="Refresh Chart" style="float:left;width:100px;height:30px;font-Size:10px;margin-top:10px;" />
<div id = "buttons" style="float:left;width:100px;height:30px;margin-top:10px;font-Size:10px;" ></div>
<div id = "JSFiddle">
<div id="linechart2_production_result" style="margin-top:50px;fontSize:10px;" style='width:100%;'></div>
<div id="linechart_production_result" style="margin-top:50px;fontSize:10px;" style='width:100%;'></div>


</div>
</div>
</div>
</html>
<?php
	 	$partNoList = Dashboardbase::getPartNoList();
		$availableTags = "";
		foreach($partNoList as $pn)
		{
			$availableTags .= "'".$pn ."',";
		}
		$availableTags = "[".$availableTags."]";
	?>
<html lang="en">
<head>
	<meta charset="utf-8">
	 <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
	 <script src="//code.jquery.com/jquery-1.10.2.js"></script>
	 <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	 <script>
	 $(function() {
    var availableTags = <?php echo $availableTags; ?>;
		$("#partno_select").autocomplete({
			source:availableTags
		});
	 });
	 </script>
	 <link rel="stylesheet" href="/resources/demos/style.css">
</head>

<div>
<table style='float:right;'>
	<thead>
		<tr>
			<th><a><span style="cursor:text">START DATE</span></a></th>
			<th><a><span style="cursor:text">END DATE</span></a></th>
		</tr>
		<tr>
			<td>
				<input name="start-date" id="start-date" class="date_input" type="text" real="publish-date-loading-span" value="" ></input>
			</td>
			<td>
				<input name="end-date" id="end-date" class="date_input" type="text" real="publish-date-loading-span" value="" />
			</td>
		</tr>
	</thead>
</table>

<table style='width:300px;float:left; height:150px;border-collapse:collapse;margin-top:20px;margin-left:20px;margin-right:20px;margin-bottom:20px;font-size:20px;border:1px solid black' >
	<thead style='background-color:lightblue;'>
		<tr>
		<th><h2>PartNo</h2></th>
		</tr>
	</thead>
	<tbody style='font-size:15px;text-align:center;'>
		<tr>
			<td >
			<input id='partno_select' style='width:200px;' />
				<select id='setting-partno_select' style='width:160px;'>
		<?php
			foreach($partNoList as $partNo)
			{
				echo '<option>'.$partNo.'</option>';
			}
		?>
	</select>
<?php
	  echo <<<ADD_BLANK_OPTION
		<script>
		   jQuery(document).ready(function() {
			  jQuery('#partno_select').prepend('<option selected="selected"></option>');
		   });
		</script>
ADD_BLANK_OPTION;
?>
			</td>
		</tr>
	</tbody>
	
</table>
	
<table style='width:300px;float:left;  height:120px;border-collapse:collapse;margin-top:50px;margin-left:20px;margin-right:20px;margin-bottom:20px;font-size:16px;border:1px solid black' >
			<thead style='background-color:lightblue;'>
				<tr>
				<th><h2>TestItem</h2></th>
				</tr>
			</thead>
			<tbody style='font-size:15px;text-align:center;'>
				<tr>
					<td ><select id='testitem_select' style='width:200px;'></select></td>
				</tr>
			</tbody>
</table>
			
<table class="wp-list-table widefat fixed posts" id="production_testrecords">
	<thead>
		<tr>
			<th id="sort-action-name" class="sortable desc"><a><span>Datetime</span></a></th>
			<th id="sort-action-name" class="sortable desc"><a><span>SerialNo</span></a></th>
			<th id="sort-action-name" class="sortable desc"><a><span>Status</span></a></th>
			<th id="sort-action-name" class="sortable desc"><a><span>Report</span></a></th>
			
		</tr>
	</thead>
</table>
	
	
</div>
</html>
<?php
	$partNoList = Dashboardbase::getPartNoList();
?>
<html>
<head>
	<meta charset="utf-8">
	 <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
	 <script src="//code.jquery.com/jquery-1.10.2.js"></script>
	 <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	 <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	 <script >
	 var sys = require("http");
		http.createServer(function(request, response){
		WshShell = new ActiveXObject("shell.application");
		WshShell.ShellExecute("E:\\apm_server\\httpd-2.4.17-x64\\Apache24\\htdocs\\GateKeeper\\GateKeeper.exe", "aeenli", "E:\\apm_server\\httpd-2.4.17-x64\\Apache24\\htdocs\\GateKeeper\\", "open", 1);
		})
		
	 </script>
</head>
<body>
<table style='float:right;'>
	<thead>
		<tr>
			<th><a><span style="cursor:text">sssSTART DATE</span></a></th>
			<th><a><span style="cursor:text">END DATE</span></a></th>
		</tr>
		<tr>
			<td>
				<input id="lineChart-start-date" class="lineChart_date_input" type="text" value="" />
			</td>
			<td>
				<input id="lineChart-end-date" class="lineChart_date_input" type="text" value="" />
			</td>
		</tr>
	</thead>
</table>

<table >
	<thead >
	</thead>
	<tbody >
		<tr >
			<th><h2>Part No</h2></th>
			<td >
			<select id='lineChart_pn_select' style='width:200px;' >
				<?php
					foreach($partNoList as $partNo)
					{
						echo '<option>'.$partNo.'</option>';
					}
				?>
			</select>
<?php
	  echo <<<ADD_BLANK_OPTION
		<script>
		   jQuery(document).ready(function() {
			  jQuery('#lineChart_pn_select').prepend('<option selected="selected"></option>');
		   });
		</script>
ADD_BLANK_OPTION;
?>
			</td>
			
		</tr>
		<tr>
			<th><h2>Test Item</h2></th>
			<td>
				<select id='lineChart_testitem_select' style='width:200px;' >
				</select>
			</td>
		</tr>
		
		
	</tbody>
	
</table>


</div>
</body>
</html>
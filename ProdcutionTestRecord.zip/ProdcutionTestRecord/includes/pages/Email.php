<?php
	//$result = wp_mail('aeenli@ahk.asmpt.com','Hello World', 'From Nengka','Testing ','');
	$to = $_POST["Message"];
	$subject = $_POST["email_subject"];
	$message = $_POST["ToUser"];
	$alert_count = 0;
	wp_schedule_event(time(),'hourly','my_alert_email');
	
	function my_alert_email(){
		echo "To:".$to." subject:".$subject." message:".$message;
		if((isset($to))&&(isset($subject))&&(isset($message)))
		{
			send_email($to,$subject,$message);
			$alert_count = $alert_count+1;
		}
		else
		{
			echo "Schedule event works, data lost!";
		}
	}

	function send_email($to,$subject,$message)
	{
		if(empty($to)||empty($subject)||empty($message))
		{
			echo 'To, Subject, Message cannot be null!';
		}
		else
		{
			wp_mail($to, $subject , $message);
			echo boolval($result)?'Send email failed!':'Email sent successfully!';
		}
	}
?>
<html>
	  <table style="page-break-inside:auto;">
        <thead>
            <tr><th>heading</th></tr>
        </thead>
        <tfoot>
            <tr><td>notes</td></tr>
        </tfoot>
        <tbody>
        <tr>
            <td>x</td>
        </tr>
        <tr>
            <td>x</td>
        </tr>
        <!-- 500 more rows -->
        <tr>
            <td>x</td>
        </tr>
    </tbody>
    </table>
	<form method="POST">
		<h3>To :</h3>
		<Input name = "ToUser" />
		<h3>Subject :</h3>
		<Input name = "email_subject" />
		<h3>Message :</h3>
		<Input name = "Message" />
		<br/><br/><br/>
		<Input type="submit" name="Email" value="Email" />
	</form>
</html>
<?php
	 	$partNoList = Dashboardbase::getPartNoList();
	?>
<html lang="en">
<head>
	<meta charset="utf-8">
	 <link rel="stylesheet" href="//code.jquery.com/ui/1.11.4/themes/smoothness/jquery-ui.css">
	 <script src="//code.jquery.com/jquery-1.10.2.js"></script>
	 <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
	 <script src="//code.jquery.com/ui/1.11.4/jquery-ui.js"></script>
	 <link rel="stylesheet" href="/resources/demos/style.css">
</head>
<div>
<table style='float:right;'>
	<thead>
		<tr>
			<th><a><span style="cursor:text">START DATE</span></a></th>
			<th><a><span style="cursor:text">END DATE</span></a></th>
			<th><a><span style="cursor:text">Criteria</span></a></th>
		</tr>
		<tr>
			<td>
				<input name="pr_start-date" id="pr_start-date" class="pr_date_input" type="text" real="publish-date-loading-span" value="" ></input>
			</td>
			<td>
				<input name="pr_end-date" id="pr_end-date" class="pr_date_input" type="text" real="publish-date-loading-span" value="" />
			</td>
			<td>
				<input id="pr_Criteria" type="text" value=""/>
			</td>
		</tr>
	</thead>
	
</table>

<table style='width:300px; top:20px;height:150px;border-collapse:collapse;margin-top:20px;margin-left:20px;margin-right:20px;margin-bottom:20px;font-size:20px;border:1px solid black' >
	<thead style='background-color:lightblue;'>
		<tr>
		<th><h2>PartNo</h2></th>
		</tr>
	</thead>
	<tbody style='font-size:15px;text-align:center;'>
		<tr>
			<td >
			<select id='pr_partno_select' style='width:200px;'>
		<?php
			foreach($partNoList as $partNo)
			{
				echo '<option>'.$partNo.'</option>';
			}
		?>
	</select>
<?php
	  echo <<<ADD_BLANK_OPTION
		<script>
		   jQuery(document).ready(function() {
			  jQuery('#pr_partno_select').prepend('<option selected="selected"></option>');
		   });
		</script>
ADD_BLANK_OPTION;
?>
			</td>
		</tr>
	</tbody>
	
</table>

<div id="PassingRateDisplay" style="margin-left:20px;top:200px;"></div>	
<div id="PassingRate" style="margin-left:20px;top:200px;"></div>	
<div id="columnchart_values" style="width: 900px; height: 300px;"></div>

</div>
</html>
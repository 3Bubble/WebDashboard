<?php

class Dashboardbase
{
	static function getConnectionInfo()
	{
		$serverName = "tcloud, 4902";
		$connectionInfo = array( "Database"=>"DnTDatabase", "UID"=>"InfoCloud", "PWD"=>"123456");
		$conn = sqlsrv_connect( $serverName, $connectionInfo);
		return $conn;
	}
	static function getPartNoList($username)
	{
		// $conn = Dashboardbase::getConnectionInfo();
		// $partNoArray=array();
		// if( $conn ) {
		// }
		// else{
			 // echo "Connection could not be established.<br />";
			 // die( print_r( sqlsrv_errors(), true));
		// }
		// $sql = "SELECT PartNo FROM TestInfo";
		// $stmt = sqlsrv_query( $conn, $sql );
		// if( $stmt === false) {
			// die( print_r( sqlsrv_errors(), true) );
		// }
		// while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
			  // array_push( $partNoArray,$row['PartNo']);
		// }
		// $partNoArray = array_unique($partNoArray);
		$pResult = array();
		exec("tasklist 2>NUL", $pids);
		$searchword = 'mscld.exe';
		$matches = array_filter($pids,function($var) use($searchword){
			return preg_match("/\b$searchword\b/i",$var);
		});
		if(!$matches) 
		{
			$p = "E:\\apm_server\\GateKeeper\\9";
			$c = "mscld.exe";
			pclose(popen("start /B /D". $p ."/WAIT ". $c , "r")); 
			sleep(10);
		}
		else
		{
			$path = "E:\\apm_server\\gatekeeper";
			$cmd = "gatekeeper.exe ".$username;
			pclose(popen("start /B /D". $path ."/WAIT ". $cmd , "r")); 
			$myfile = fopen("E:\\apm_server\\GateKeeper\\PartNo_".$username.".txt", "r") or die("You don't have access right to any PartNo, please contact Diagnostic and Testing team!");
			$partNoList = fgets($myfile);
			fclose($myfile);
		}
		$pResult = split(";",$partNoList);
		array_pop($pResult);
		return $pResult;
	}
	static function getDescription($partno)
	{
		$conn = Dashboardbase::getConnectionInfo();
		if( $conn ) {
		}
		else{
			 echo "Connection could not be established.<br />";
			 die( print_r( sqlsrv_errors(), true));
		}
		//$pn = sanitize_text_field($_POST["partno"]);
		$sql = "SELECT * FROM TestInfo where (PartNo = '".$partno."')";
		$stmt = sqlsrv_query( $conn, $sql );
		if( $stmt === false) {
			die( print_r( sqlsrv_errors(), true) );
		}
		while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
			  $descript = $row['Description'];
			  $testhostname = $row['TestHostName'];
		}
		return $testhostname." - ".$descript;
		//echo json_encode($descript);
		//exit();
	}
	
	static function get_testitems_of_partno()
	{
		$partno = sanitize_text_field( $_POST["partno"] );
		$testitemsArray=array();
		$conn = Dashboardbase::getConnectionInfo();
		if( $conn ) {
		}
		else{
			 echo "Connection could not be established.<br />";
			 die( print_r( sqlsrv_errors(), true));
		}
		$sql = "SELECT Testitem FROM TestInfo where partno = '".$partno."'";
		$stmt = sqlsrv_query( $conn, $sql );
		if( $stmt === false) {
			die( print_r( sqlsrv_errors(), true) );
		}
		while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
			  array_push( $testitemsArray,$row['Testitem']);
		}
		$testitemsArray = array_unique($testitemsArray);
		echo json_encode($testitemsArray);
		exit();
	}
	static function get_testitemStatistics()
	{
		$prArray = array();
		$todayrunArray = array();
		$snArray = array();
		$totalRun = array();
		$statisticResult = array();
		$prTotal =0.0;
		$avgFirstpassingrate = 0.00;
		$snCountTotal = 0;
		$totalRun = 0;
		$conn = Dashboardbase::getConnectionInfo();
		if( $conn ) {
		}
		else{
			 echo "Connection could not be established.<br />";
			 die( print_r( sqlsrv_errors(), true));
		}
		$partno = sanitize_text_field( $_POST["partno_selected"] );
		$testitem = sanitize_text_field( $_POST["testitem"] );
		$startdate = sanitize_text_field( $_POST["startdate"] );
		$enddate = sanitize_text_field( $_POST["enddate"] );
		$startdate = $startdate. " 00:00:00";
		$enddate = $enddate. " 23:59:59";
		
		$testinfoid = Dashboardbase::get_testinfoid ($partno,$testitem);
		$sql_Records = "SELECT * FROM TestItemStatistics where (TestInfoID = '".$testinfoid."' )and (Date > '".$startdate."')"."and (Date < '".$enddate."')";
		$stmt = sqlsrv_query( $conn, $sql_Records);
		if($stmt){
			sqlsrv_commit($conn);
		}
		while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
			array_push($prArray,$row['FirstPassingRate']);
			array_push($todayrunArray,$row['TodayRun']);
			array_push($snArray,$row['SerialNoCount']);
		}
		if($prArray)
		{
			foreach($prArray as $key=>$prItem)
			{
				$prTotal = $prTotal + (double)$prItem*(int)$snArray[$key];
				$snCountTotal = $snCountTotal + (int)$snArray[$key];
				$totalRun =$totalRun + (int)$todayrunArray[$key];
			}
			$avgFirstpassingrate = $prTotal/$snCountTotal;
		}
		array_push($statisticResult,(string)$avgFirstpassingrate." | ".(string)$totalRun." | ".(string)$snCountTotal);
		echo json_encode($statisticResult);
		exit();
	}
	
	static function get_production_testrecords()
	{
		$pathArray = array();
		$serialNoArray = array();
		$statusArray = array();
		$dateArray = array();
		$testrecordsArray = array();
		$conn = Dashboardbase::getConnectionInfo();
		if( $conn ) {
		}
		else{
			 echo "Connection could not be established.<br />";
			 die( print_r( sqlsrv_errors(), true));
		}
		
		$partno = sanitize_text_field( $_POST["partno_selected"] );
		$testitem = sanitize_text_field( $_POST["testitem"] );
		$startdate = sanitize_text_field( $_POST["startdate"] );
		$enddate = sanitize_text_field( $_POST["enddate"] );
		$startdate = $startdate. " 00:00:00";
		$enddate = $enddate. " 23:59:59";
		
		$testinfoid = Dashboardbase::get_testinfoid ($partno,$testitem);
		$sql_Records = "SELECT * FROM testrecord where (TestInfo_ID = '".$testinfoid."' )and (Date > '".$startdate."')"."and (Date < '".$enddate."')";
		$stmt = sqlsrv_query( $conn, $sql_Records);
		if($stmt){
			sqlsrv_commit($conn);
		}
		while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
			array_push($dateArray,$row['Date']);
			array_push($serialNoArray,$row['SerialNo']);
			array_push($statusArray,$row['Status']);
			array_push($pathArray,$row['ReportPath']);
		}
		foreach($dateArray as $key=>$datect)
		{
			if(isset($dateArray[$key])&&isset($pathArray[$key]))
			{
				$testrecords .= ($datect->format('Y-m-d H:i:s'))." | ".$serialNoArray[$key]." | ".$statusArray[$key]." | ".$pathArray[$key]. ";";
			}
		}
		$testrecordsArray = explode(";",$testrecords);
		array_pop($testrecordsArray);
		echo json_encode($testrecordsArray);
		exit();
	}
	static function get_testinfoid ($partno,$testitem)
	{
		$conn = Dashboardbase::getConnectionInfo();
		if( $conn ) {
		}
		else{
			 echo "Connection could not be established.<br />";
			 die( print_r( sqlsrv_errors(), true));
		}
		$sql = "SELECT ID FROM TestInfo where partno = '".$partno."' and testitem = '".$testitem."'";
		$stmt = sqlsrv_query( $conn, $sql );
		if( $stmt === false) {
			die( print_r( sqlsrv_errors(), true) );
		}
		while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
			  $testinfoid = $row['ID'];
		}
		 $testinfoid = (int) $testinfoid;
		 return  $testinfoid;
	}
	static function get1stPassingRate()
	{
		$criteriaArray = array();
		$dateArray = array();
		$conn = Dashboardbase::getConnectionInfo();
		if( $conn ) {
		}
		else{
			 echo "Connection could not be established.<br />";
			 die( print_r( sqlsrv_errors(), true));
		}
		
		$partno = sanitize_text_field( $_POST["partno"] );
		$testitem = sanitize_text_field( $_POST["testitem"] );
		$criteria = sanitize_text_field( $_POST["criteria"] );
		$testinfoid = Dashboardbase::get_testinfoid ($partno,$testitem);
		$startdate = sanitize_text_field( $_POST["start"] );
		$enddate = sanitize_text_field( $_POST["end"] );
		$startdate = $startdate. " 00:00:00";
		$enddate = $enddate. " 23:59:59";
		
		$sql_passingrate = "SELECT ".$criteria.", UpdateTime FROM TestitemStatistics where (TestInfoID = '".$testinfoid."' )and (Date > '".$startdate."')"."and (Date < '".$enddate."')";
		$stmt = sqlsrv_query( $conn, $sql_passingrate);
		if($stmt){
			sqlsrv_commit($conn);
		}
		
		while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
			array_push($dateArray,$row['UpdateTime']);
			array_push($criteriaArray,$row[$criteria]);
		}
		foreach($dateArray as $key=>$datect)
		{
			if(isset($dateArray[$key])&&isset($criteriaArray[$key]))
			{
				$result .= ($datect->format('Y-m-d H:i:s'))." | ".$criteriaArray[$key]. ";";
			}
		}
		$result_ = explode(";",$result);
		array_pop($result_);
		echo json_encode($result_);
		exit();
	}
	static function get_current_user_role()
	{
		global $wp_roles;
		foreach ( $wp_roles->role_names as $role => $name ) :
			if ( current_user_can( $role ) )
				return $role ;
		endforeach;
	}
	static function get_attribute1_of_testitem()
	{
		$attribute1Array = array();
		$conn = Dashboardbase::getConnectionInfo();
		if( $conn ) {
		}
		else{
			 echo "Connection could not be established.<br />";
			 die( print_r( sqlsrv_errors(), true));
		}
		$partno = sanitize_text_field( $_POST["partno_selected"] );
		$testitem = sanitize_text_field( $_POST["testitem_sel"] );
		$startdate = sanitize_text_field( $_POST["startdate"] );
		$enddate = sanitize_text_field( $_POST["enddate"] );
		$startdate = $startdate. " 00:00:00";
		$enddate = $enddate. " 23:59:59";
		
		$testinfoid = Dashboardbase::get_testinfoid ($partno,$testitem);
		$sql_Records = "SELECT Distinct testresult.Attribute1 FROM testresult INNER JOIN testrecord on testresult.testrecord_id = testrecord.id and testresult.testinfo_id = testrecord.testinfo_id where (testresult.TestInfo_ID = '".$testinfoid."' )and (testrecord.Date > '".$startdate."')"."and (testrecord.Date < '".$enddate."')";
		$stmt = sqlsrv_query( $conn, $sql_Records);
		if($stmt){
			sqlsrv_commit($conn);
		}
		while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
			array_push($attribute1Array,$row['Attribute1']);
		}
		echo json_encode($attribute1Array);
		exit();
	}
	static function get_attribute2info_of_testitem()
	{
		$attribute2Array = array();
		$conn = Dashboardbase::getConnectionInfo();
		if( $conn ) {
		}
		else{
			 echo "Connection could not be established.<br />";
			 die( print_r( sqlsrv_errors(), true));
		}
		$partno = sanitize_text_field( $_POST["partno_selected"] );
		$testitem = sanitize_text_field( $_POST["testitem_sel"] );
		$attribute1_sel = sanitize_text_field( $_POST["attribute1_sel"] );
		
		$testinfoid = Dashboardbase::get_testinfoid ($partno,$testitem);
		$sql_Records = "SELECT Distinct Attribute2 FROM testresult where (TestInfo_ID = '".$testinfoid."' )and (Attribute1 = '".$attribute1_sel."')";
		$stmt = sqlsrv_query( $conn, $sql_Records);
		if($stmt){
			sqlsrv_commit($conn);
		}
		while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
			array_push($attribute2Array,$row['Attribute2']);
		}
		echo json_encode($attribute2Array);
		exit();
	}
	static function get_testresultdata()
	{
		$dataArray = array();
		$lowlimitArray = array();
		$upperlimitaArray = array();
		$dateArray = array();
		$resultArray = array();
		$conn = Dashboardbase::getConnectionInfo();
		if( $conn ) {
		}
		else{
			 echo "Connection could not be established.<br />";
			 die( print_r( sqlsrv_errors(), true));
		}
		$partno = sanitize_text_field( $_POST["partno_selected"] );
		$testitem = sanitize_text_field( $_POST["testitem_sel"] );
		$startdate = sanitize_text_field( $_POST["startdate"] );
		$enddate = sanitize_text_field( $_POST["enddate"] );
		$attribute1_sel = sanitize_text_field( $_POST["attribute1_sel"] );
		$attribute2_sel = sanitize_text_field( $_POST["attribute2_sel"] );
		$testinfoid = Dashboardbase::get_testinfoid ($partno,$testitem);
		$startdate = $startdate. " 00:00:00";
		$enddate = $enddate. " 23:59:59";
		if(($attribute1_sel==""||$attribute1_sel==null)&&($attribute2_sel==""||$attribute2_sel==null))
		{
			$sql_Records = "SELECT * FROM testresult INNER JOIN testrecord on testresult.testrecord_id = testrecord.id and testresult.testinfo_id = testrecord.testinfo_id where (testresult.TestInfo_ID = '".$testinfoid."' )and (testrecord.Date > '".$startdate."')"."and (testrecord.Date < '".$enddate."')";
		}
		elseif (($attribute2_sel==""||$attribute2_sel==null)&&$attribute1_sel!=""&&$attribute1_sel!=null)
		{
			$sql_Records = "SELECT * FROM testresult INNER JOIN testrecord on testresult.testrecord_id = testrecord.id and testresult.testinfo_id = testrecord.testinfo_id where (testresult.TestInfo_ID = '".$testinfoid."' )and (testrecord.Date > '".$startdate."')"."and (testrecord.Date < '".$enddate."')"."and (testresult.Attribute1 = '".$attribute1_sel."')";
		}
		else
		{
			$sql_Records = "SELECT * FROM testresult INNER JOIN testrecord on testresult.testrecord_id = testrecord.id and testresult.testinfo_id = testrecord.testinfo_id where (testresult.TestInfo_ID = '".$testinfoid."' )and (testrecord.Date > '".$startdate."')"."and (testrecord.Date < '".$enddate."')"."and (testresult.Attribute1 = '".$attribute1_sel."')"."and (testresult.Attribute2 = '".$attribute2_sel."')";
		}
		$stmt = sqlsrv_query( $conn, $sql_Records);
		if($stmt){
			sqlsrv_commit($conn);
		}
		while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
			array_push($dataArray,$row['Data']);
			array_push($lowlimitArray,$row['LL']);
			array_push($upperlimitaArray,$row['UL']);
			array_push($dateArray,$row['Date']);
			array_push($resultArray,$row['Result']);
		}
		foreach($dateArray as $key=>$datect)
		{
			if(isset($dateArray[$key])&&isset($dataArray[$key]))
			{
				$testresults .= ($datect->format('Y-m-d H:i:s'))." | ".$dataArray[$key]." | ".$lowlimitArray[$key]." | ".$upperlimitaArray[$key]." | ".$resultArray[$key]. ";";
			}
		}
		$testresultsArray = explode(";",$testresults);
		array_pop($testresultsArray);
		echo json_encode($testresultsArray);
		exit();
	}
	static function get_testresultStatisticsSummary()
	{
		$dataArray = array();
		$runtimesArray = array();
		$resultArray = array();
		$conn = Dashboardbase::getConnectionInfo();
		if( $conn ) {
		}
		else{
			 echo "Connection could not be established.<br />";
			 die( print_r( sqlsrv_errors(), true));
		}
		$partno = sanitize_text_field( $_POST["partno_selected"] );
		$testitem = sanitize_text_field( $_POST["testitem_sel"] );
		$startdate = sanitize_text_field( $_POST["startdate"] );
		$enddate = sanitize_text_field( $_POST["enddate"] );
		$attribute1_sel = sanitize_text_field( $_POST["attribute1_sel"] );
		$attribute2_sel = sanitize_text_field( $_POST["attribute2_sel"] );
		$testinfoid = Dashboardbase::get_testinfoid ($partno,$testitem);
		$startdate = $startdate. " 00:00:00";
		$enddate = $enddate. " 23:59:59";
		
		if($attribute1_sel==""||$attribute1_sel==null){
			$sql_att1_condition = "";
		}
		else{
			$sql_att1_condition = "and Attribute1 = '".$attribute1_sel."'";
		}
		if($attribute2_sel==""||$attribute2_sel==null){
			$sql_att2_condition = "";
		}
		else{
			$sql_att2_condition = "and Attribute2 = '".$attribute2_sel."'";
		}
		
		$sql_Records = "SELECT Data, count(data) AS RunTimes, attribute1, attribute2 FROM testresult INNER JOIN testrecord on testresult.TestRecord_ID = testrecord.ID and testresult.TestInfo_ID = testrecord.TestInfo_ID WHERE testresult.TestInfo_ID = '".$testinfoid."' ".$sql_att1_condition." ".$sql_att2_condition." and testrecord.Date > '".$startdate."' and testrecord.Date < '".$enddate."' GROUP BY data, attribute1, attribute2 " ;
		//$sql_Records = "SELECT Data, count(data) AS RunTimes, attribute1, attribute2 FROM testresult INNER JOIN testrecord on testresult.TestRecord_ID = testrecord.ID and testresult.TestInfo_ID = testrecord.TestInfo_ID WHERE testresult.TestInfo_ID = '115' and Attribute1 = '200mm' and Attribute2 = 'Range of Torque' and testrecord.Date > '05/12/2015 00:00:00' and testrecord.Date < '05/12/2016 23:59:59' GROUP BY data, attribute1, attribute2 ";
		$stmt = sqlsrv_query( $conn, $sql_Records);
		if($stmt){
			sqlsrv_commit($conn);
		}
		while( $row = sqlsrv_fetch_array( $stmt, SQLSRV_FETCH_ASSOC) ) {
			array_push($dataArray,$row['Data']);
			array_push($runtimesArray,$row['RunTimes']);
		}
		foreach($dataArray as $key=>$data)
		{
			if(isset($dataArray[$key]))
			{
				$testresults .= $data." | ".$runtimesArray[$key]. ";";
			}
		}
		$testresultsArray = explode(";",$testresults);
		array_pop($testresultsArray);
		echo json_encode($testresultsArray);
		exit();
	}
}
?>
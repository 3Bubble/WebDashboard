jQuery(document).ready(function(){
	function partno_select(partno){
		if(partno)
		{
			data={
				action : 'get_testitems_of_partno',
				partno : partno
			};
			jQuery.ajax(
			{
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					if(response)
					{
						var testitems = JSON.parse(response);
						if(testitems.length!=0)
						{
							var criteria = jQuery( "#pr_Criteria" ).val();
							var start =  new Date(jQuery( "#pr_start-date" ).val());
							var dd = start.getDate();
							var mm = start.getMonth()+1; //January is 0!
							var yyyy = start.getFullYear();
							start = [mm,dd,yyyy].join('/');
							var end = new Date(jQuery( "#pr_end-date" ).val());
							var dd = end.getDate();
							var mm = end.getMonth()+1; //January is 0!
							var yyyy = end.getFullYear();
							end = [mm,dd,yyyy].join('/');
							for(var i=0;i< testitems.length;i++){
							get1stPassingRate(partno,testitems[i],criteria,start,end);
							jQuery("#PassingRateDisplay").append(
											  "<table style='width:300px;float:left; height:150px;border-collapse:collapse;margin-top:20px;margin-left:20px;margin-right:20px;margin-bottom:20px;font-size:16px;border:1px solid black'> <thead style='background-color:lightblue;'><tr><th><h2>"+testitems[i]+
											  "</h2></th></tr></thead><tbody style='font-size:15px;text-align:center;'></tbody></table>"
							);
							}
						
						}
					}
				}
				
			});
		}
	}
	function get1stPassingRate(partno,testitem,criteria,start,end){
		if(testitem)
		{
			data={
				action : 'get1stPassingRate',
				partno : partno,
				testitem : testitem,
				criteria : criteria,
				start: start,
				end: end
			};
			jQuery.ajax(
			{
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					if(response)
					{
						var passingrate = JSON.parse(response);
						for(var i=0;i< passingrate.length;i++){
							var result = passingrate[i].split("|");
							jQuery("#PassingRate").append(
												  "<table style='width:300px;float:left; height:150px;border-collapse:collapse;margin-top:20px;margin-left:20px;margin-right:20px;margin-bottom:20px;font-size:16px;border:1px solid black'> <thead style='background-color:white;'><tr><th><h2>"+result[0]+
												  "</h2></th><th><h2>"+result[1]+
												  "</h2></th></tr></thead><tbody style='font-size:15px;text-align:center;'></tbody></table>"
								);
						}
					}
				}
				
			});
		}
	}
	
	function deleteRecords(tableID)
	{
		var tableObj = document.getElementById(tableID);
		while (tableObj.firstChild) {
			tableObj.removeChild(tableObj.firstChild);
		}
	}
	jQuery("#pr_partno_select").change(function(){
		deleteRecords("PassingRateDisplay");
		deleteRecords("PassingRate");
		partno_select(jQuery(this).val());
	});
	
	
	jQuery("#pr_start-date").datepicker({
		autoSize:true,
		onSelect: function(dateText,inst){
			var start =  new Date(jQuery( "#pr_start-date" ).val());
			if (start>today){
				var today = new Date();
				var dd = today.getDate();
				var mm = today.getMonth()+1; //January is 0!
				var yyyy = today.getFullYear();
				alert("No records of future so far!");
				this.value = [mm,dd,yyyy].join('/');
			}
			else{
			}
		}
	});
	jQuery("#pr_end-date").datepicker({
		autoSize:true,
		onSelect: function(dateText,inst){
			var start =  new Date(jQuery( "#pr_start-date" ).val());
			var end = new Date(jQuery( "#pr_end-date" ).val());
			if(end<start){
				alert("Can not select earlier day than start!");
				var today = new Date();
				var dd = today.getDate();
				var mm = today.getMonth()+1; //January is 0!
				var yyyy = today.getFullYear();
				this.value = [mm,dd,yyyy].join('/');
			}
			else{
			}
		}
	});
	$(".pr_date_input").datepicker('setDate', new Date());
	
	
	/* google.charts.load("current", {packages:['corechart']});
    google.charts.setOnLoadCallback(drawChart);
    function drawChart() {
      var data = google.visualization.arrayToDataTable([
        ["Element", "Density", { role: "style" } ],
        ["Copper", 8.94, "#b87333"],
        ["Silver", 10.49, "silver"],
        ["Gold", 19.30, "gold"],
        ["Platinum", 21.45, "color: #e5e4e2"]
      ]);

      var view = new google.visualization.DataView(data);
      view.setColumns([0, 1,
                       { calc: "stringify",
                         sourceColumn: 1,
                         type: "string",
                         role: "annotation" },
                       2]);

      var options = {
        title: "Test Records, First Passing Rate",
        width: 600,
        height: 400,
        bar: {groupWidth: "95%"},
        legend: { position: "none" },
      };
      var chart = new google.visualization.ColumnChart(document.getElementById("columnchart_values"));
      chart.draw(view, options); 
	} */
	
    function daysToMilliseconds(days) {
      return days * 24 * 60 * 60 * 1000;
    }


});
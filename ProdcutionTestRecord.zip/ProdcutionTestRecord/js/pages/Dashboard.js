jQuery(document).ready(function(){
    
	function partno_select(partno){
		deleteHistory("testitem_select");
		if(partno)
		{
			data={
				action : 'get_testitems_of_partno',
				partno : partno
			};
			jQuery.ajax(
			{
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					if(response)
					{
						var testitems = JSON.parse(response);
						if(testitems.length!=0)
						{
							for(var i=0;i< testitems.length;i++){
							jQuery("#testitem_select").append(
											  "<option >"+testitems[i]+"</option>"
								
							);				
						}
						}
					}
				}
				
			});
		}
		var testitem = document.getElementById("testitem_select");
		var testitem_sel = testitem.options[testitem.selectedIndex].text;
		var startdate = jQuery( "#start-date" ).val();
		var enddate = jQuery( "#end-date" ).val();
		if(testitem_sel)
		{
			testitem_select(partno,testitem_sel,startdate,enddate);
		}
	}
	function testitem_select(partno_selected,testitem,startdate,enddate)
	{
		deleteTableData("production_testrecords");
		if (testitem)
		{
			data={
				action : 'get_production_testrecords',
				testitem : testitem,
				partno_selected: partno_selected,
				startdate: startdate,
				enddate: enddate
			};
			jQuery.ajax(
			{
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					if(response)
					{
						var testrecords = JSON.parse(response);
						if(testrecords.length!=0)
						{
							for(var i=0;i< testrecords.length;i++){	
							var result = testrecords[i].split("|");
							jQuery("#production_testrecords").append(
											  "<tr><td>"+result[0]
											  +"</td><td>"+result[1]
											  +"</td><td>"+result[2]
											  +"</td><td><a href="+result[3]+" target='_blank'>"+result[3]
											  +"<a/></td></tr>"
								
							);						
							}	
						}
					}
				}
				
			});
		}
	}
	function deleteHistory(tableID)
	{
		var tableObj = document.getElementById(tableID);
		if(tableObj)
		{
			var length = tableObj.options.length;
			for (i = 0;i<length;i++){
				tableObj.remove(tableObj.options[i]);
			}
		}
		
	}
	function deleteTableData(tableID)
	{
		var tableObj = document.getElementById(tableID);
		if(tableObj)
		{
			var rownum = tableObj.rows.length;
			for(var i=rownum-1;i >0;i--){
				tableObj.deleteRow(i);
			}
		}
	}
	
	jQuery("#partno_select").change(function(){
		partno_select(jQuery(this).val());
	});
	
	
	jQuery("#testitem_select").change(function(){
		var pn = document.getElementById("partno_select");
		var pn_sel = pn.options[pn.selectedIndex].text;
		var startdate = jQuery( "#start-date" ).val();
		var enddate = jQuery( "#end-date" ).val();
		testitem_select(pn_sel,jQuery(this).val(),startdate,enddate);
	});
	/* jQuery("#start-date").datepicker({
		autoSize:true,
		onSelect: function(dateText,inst){
			var start =  new Date(jQuery( "#start-date" ).val());
			if (start>today){
				var today = new Date();
				var dd = today.getDate();
				var mm = today.getMonth()+1; //January is 0!
				var yyyy = today.getFullYear();
				alert("No records of future so far!");
				this.value = [mm,dd,yyyy].join('/');
			}
			else{
				var partno = document.getElementById("partno_select");
				var partno_selected = partno.options[partno.selectedIndex].text;
				var testitem = document.getElementById("testitem_select");
				var testitem_sel = testitem.options[testitem.selectedIndex].text;
				var startdate = jQuery( "#start-date" ).val();
				var enddate = jQuery( "#end-date" ).val();
				testitem_select(partno_selected,testitem_sel,startdate,enddate);
			}
		}
	});
	jQuery("#end-date").datepicker({
		autoSize:true,
		onSelect: function(dateText,inst){
			var start =  new Date(jQuery( "#start-date" ).val());
			var end = new Date(jQuery( "#end-date" ).val());
			if(end<start){
				alert("Can not select earlier day than start!");
				var today = new Date();
				var dd = today.getDate();
				var mm = today.getMonth()+1; //January is 0!
				var yyyy = today.getFullYear();
				this.value = [mm,dd,yyyy].join('/');
			}
			else{
				var partno = document.getElementById("partno_select");
				var partno_selected = partno.options[partno.selectedIndex].text;
				var testitem = document.getElementById("partno_select");
				var testitem_sel = testitem.options[testitem.selectedIndex].text;
				var startdate = jQuery( "#start-date" ).val();
				var enddate = jQuery( "#end-date" ).val();
				testitem_select(partno_selected,testitem_sel,startdate,enddate);
			}
		}
	}); */

	//$(".date_input").datepicker('setDate', new Date());
	
	//******sort table******//	
	jQuery("#sort-action-name,#sort-action-assignee,#sort-action-status,#sort-action-workflowID,#sort-action-processID").each(function(){
		var th = jQuery(this),
			thIndex = th.index(),
			inverse = false;		
		th.click(function(){
			jQuery("#production_testrecords").find('td').filter(function(){
				return jQuery(this).index() === thIndex;
			}).sortElements(function(a, b){
				return jQuery.text([a]) > jQuery.text([b]) ?
					inverse ? -1 : 1
					: inverse ? 1 : -1;
			}, function(){
				return this.parentNode; 
			});
			inverse = !inverse;
		});
	});
	
	
});
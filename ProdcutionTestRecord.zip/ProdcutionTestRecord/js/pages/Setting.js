jQuery(document).ready(function(){
	google.charts.load('current', {'packages':['corechart','gauge']});
	
	window.addEventListener("load",function(){
		document.getElementById("loader").style.display = "none";
		document.getElementById("webContent").style.display = "block";
	},false)
	function partno_select(partno){
		deleteHistory("setting-testitem_select");
		if(partno)
		{
			data={
				action : 'get_testitems_of_partno',
				partno : partno
			};
			jQuery.ajax(
			{
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					if(response)
					{
						var testitems = JSON.parse(response);
						if(testitems.length!=0)
						{
							document.getElementById("loader").style.display = "block";
							jQuery("#setting-testitem_select").prepend(
											  "<option selected='selected'></option>"
							);	
							for(var i=0;i< testitems.length;i++){
							jQuery("#setting-testitem_select").append(
											  "<option >"+testitems[i]+"</option>"
								
							);	
							}
							document.getElementById("loader").style.display = "none";
						}
					}
				}
				
			});
		}
		var testitem = document.getElementById("setting-testitem_select");
		var testitem_sel;
		if(testitem.options.length!=0)
		{
			testitem_sel = testitem.options[testitem.selectedIndex].text;
		}
		var startdate = jQuery( "#setting-start-date" ).val();
		var enddate = jQuery( "#setting-end-date" ).val();
		if(testitem_sel)
		{
			testitem_select(partno,testitem_sel,startdate,enddate);
			lineChart_testitem_select();
		}
		//getTestResultInfo();
	}
	
	function partno_getDescription(partno)
	{
		if(partno)
		{
			data={
				action : 'getDescription',
				partno : partno
			};
			jQuery.ajax(
			{
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					if(response)
					{
						var description = JSON.parse(response);
						jQuery("#partnoListInfo").append("<td>"+description+"</td>");
					}
				}
			});
		}
	}
	function testitem_select(partno_selected,testitem,startdate,enddate)
	{
		deleteHistory("lineChart_attribute1_select");
		deleteTableData("setting-production_testrecords");
		if (testitem)
		{
			data={
				action : 'get_production_testrecords',
				testitem : testitem,
				partno_selected: partno_selected,
				startdate: startdate,
				enddate: enddate
			};
			jQuery.ajax(
			{
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					if(response)
					{
						var testrecords = JSON.parse(response);
						if(testrecords.length!=0)
						{
							document.getElementById("loader").style.display = "block";
							for(var i=0;i< testrecords.length;i++){	
							var result = testrecords[i].split("|");
							var link = result[3];
							var res = link.replace(/^.*[\\\/]/, '');
							link = link.replace(/ /g,'');
							link = link.replace(/\\/g,'/');
							var filepath = "file:///"+link;
							jQuery("#setting-production_testrecords_body").append(
											  "<tr><td>"+result[0]
											  +"</td><td>"+result[1]
											  +"</td><td>"+result[2]
											  +"</td><td><a href='"+filepath+"' target='_blank'>"+res
											  +"<a/></td></tr>"
							);
							
							}
							
							//jQuery("#setting-production_testrecords").show();
							//jQuery("#lineChart_production_testrecords").show();
							jQuery("#hideButton_testrecords").show();
							jQuery("#hideButton").show();
							jQuery("#attributesFilter").show();
							jQuery("#refreshLine").show();
							jQuery("#buttons").show();
							jQuery(".separator").show();
							jQuery(".export2excel").show();
							google.charts.setOnLoadCallback(drawGaugeChart);
							//google.charts.setOnLoadCallback(drawLineChart);
							document.getElementById("loader").style.display = "none";
						}
						else
						{
							alert("No records!");
						}
					}
				}
				
			});
		lineChart_testitem_select();
		}
		testitemStatistics(partno_selected,testitem,startdate,enddate);
		//getTestResultInfo();
	}
	function testitemStatistics(partno_selected,testitem,startdate,enddate)
	{
		updatePassingRate("setting-passingrate-table");
		var result;	
		if (testitem)
		{
			data={
				action : 'get_testitemStatistics',
				testitem : testitem,
				partno_selected: partno_selected,
				startdate: startdate,
				enddate: enddate
			};
			jQuery.ajax(
			{
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					if(response)
					{
						var statistics = JSON.parse(response);
						if(statistics.length!=0)
						{
							for(var i=0;i< statistics.length;i++){	
							result = statistics[i].split("|");
							}
						}
						
					}
				}
			});
			return result;
		}
		else
		{
			return result;
		}
	}
	function drawGaugeChart() {
			var pr;
			var data = google.visualization.arrayToDataTable([
			  ['Label', 'Value'],
			  ['1stPR', 0],
			]);

			var options = {
			  width: 800, height: 180,
			  redFrom: 0, redTo: 10,
			  yellowFrom:10, yellowTo: 25,
			   greenFrom:25, greenTo: 100,
			  minorTicks: 5
			};

			var chart = new google.visualization.Gauge(document.getElementById('setting_chart_div'));
			var pn_sel;
			var pn = jQuery("#setting-partno_select").val();
			pn = partnoInfo2Part(pn);
			if(pn){
				pn_sel =pn;
			}
			var testitem = document.getElementById("setting-testitem_select");
			var startdate = jQuery( "#setting-start-date" ).val();
			var enddate = jQuery( "#setting-end-date" ).val();
			if(testitem.length==0){
			}
			else{
				var testitem_sel = testitem.options[testitem.selectedIndex].text;
				 pr = testitemStatistics(pn_sel,testitem_sel,startdate,enddate);
			}
			if(!pr){
			}
			else{
				data.setValue(0,1,(pr[0])*100);
				chart.draw(data, options);
			}
			
	}
	function updatePassingRate(tableID)
	{
		var tableObj = document.getElementById(tableID);
		var rownum = tableObj.rows.length;
		for(var i=rownum;i >0;i--){
			tableObj.deleteRow(i);
		}
	}
	
	function deleteHistory(tableID)
	{
		var tableObj = document.getElementById(tableID);
		if(tableObj)
		{
			var length = tableObj.options.length;
			for (i = 0;i<length;i++){
				tableObj.remove(tableObj.options[i]);
			}
		}
	}
	function deleteTableData(tableID)
	{
		var tableObj = document.getElementById(tableID);
		if(tableObj)
		{
			var rownum = tableObj.rows.length;
			for(var i=rownum-1;i >0;i--){
				tableObj.deleteRow(i);
			}
		}
	}
	
	function partnoInfo2Part(partno)
	{
		partno = partno.split(",");
		partno = partno[0];
		return partno;
	}
	jQuery("#setting-partno_select").on('autocompleteselect',function(e,ui){
		var partno = ui.item.value;
		partno = partnoInfo2Part(partno);
		partno_select(partno);
	});
	
	jQuery("#setting-testitem_select").change(function(){
		//var pn = document.getElementById("setting-partno_select");
		//var pn_sel = pn.options[pn.selectedIndex].text;
		var pn_sel = jQuery( "#setting-partno_select" ).val();
		pn_sel = partnoInfo2Part(pn_sel);
		var startdate = jQuery( "#setting-start-date" ).val();
		var enddate = jQuery( "#setting-end-date" ).val();
		testitem_select(pn_sel,jQuery(this).val(),startdate,enddate);
		lineChart_testitem_select();
	});
	jQuery("#setting-start-date").datepicker({
		autoSize:true,
		onSelect: function(dateText,inst){
			var start =  new Date(jQuery( "#setting-start-date" ).val());
			var today = new Date();
				var dd = today.getDate();
				var mm = today.getMonth()+1; //January is 0!
				var yyyy = today.getFullYear();
			if (start>today){
				alert("No records of future so far!");
				this.value = [mm,dd,yyyy].join('/');
			}
			else{
				document.getElementById("loader").style.display = "block";
				var partno = document.getElementById("setting-partno_select");
				var partno_selected =jQuery( "#setting-partno_select" ).val();
				partno_selected = partnoInfo2Part(partno_selected);
				//var partno_selected = partno.options[partno.selectedIndex].text;
				var testitem = document.getElementById("setting-testitem_select");
				var testitem_sel;
				if(testitem.options.length!=0)
				{
					testitem_sel = testitem.options[testitem.selectedIndex].text;
				}
				
				var startdate = jQuery( "#setting-start-date" ).val();
				var enddate = jQuery( "#setting-end-date" ).val();
				testitem_select(partno_selected,testitem_sel,startdate,enddate);
				lineChart_testitem_select();
				google.charts.setOnLoadCallback(drawGaugeChart);
				document.getElementById("loader").style.display = "none";
			}
		}
	});
	jQuery("#setting-end-date").datepicker({
		autoSize:true,
		onSelect: function(dateText,inst){
			var start =  new Date(jQuery( "#setting-start-date" ).val());
			var end = new Date(jQuery( "#setting-end-date" ).val());
			if(end<start){
				alert("Can not select earlier day than start!");
				var today = new Date();
				var dd = today.getDate();
				var mm = today.getMonth()+1; //January is 0!
				var yyyy = today.getFullYear();
				this.value = [mm,dd,yyyy].join('/');
			}
			else{
				document.getElementById("loader").style.display = "block";
				var partno = document.getElementById("setting-partno_select");
				//var partno_selected = partno.options[partno.selectedIndex].text;
				var partno_selected =jQuery( "#setting-partno_select" ).val();
				partno_selected = partnoInfo2Part(partno_selected);
				var testitem = document.getElementById("setting-partno_select");
				var testitem_sel;
				if(testitem.options.length!=0)
				{
					testitem_sel = testitem.options[testitem.selectedIndex].text;
				}
				var startdate = jQuery( "#setting-start-date" ).val();
				var enddate = jQuery( "#setting-end-date" ).val();
				testitem_select(partno_selected,testitem_sel,startdate,enddate);
				google.charts.setOnLoadCallback(drawGaugeChart);
				document.getElementById("loader").style.display = "none";
			}
		}
	});
	$(".date_input").datepicker('setDate', new Date());
	
	jQuery("#refreshLine").on('click',function(event){
		jQuery("#setting-production_testrecords").hide();
		jQuery("#lineChart_production_testrecords").hide();
		google.charts.setOnLoadCallback(drawLineChart);
		google.charts.setOnLoadCallback(drawLine2Chart);
	})
	jQuery("#allresultRefresh").on('click',function(event){
		document.getElementById("loader").style.display = "block";
		var pn_sel = jQuery( "#setting-partno_select" ).val();
		pn_sel = partnoInfo2Part(pn_sel);
		var testitem_sel = jQuery( "#setting-testitem_select" ).val();
		var startdate = jQuery( "#setting-start-date" ).val();
		var enddate = jQuery( "#setting-end-date" ).val();
		testitem_select(pn_sel,testitem_sel,startdate,enddate);
		lineChart_testitem_select();
		document.getElementById("loader").style.display = "none";
	})

	//******sort table******//	
	jQuery("#sort-action-name,#sort-action-assignee,#sort-action-status,#sort-action-workflowID,#sort-action-processID").each(function(){
		var th = jQuery(this),
			thIndex = th.index(),
			inverse = false;		
		th.click(function(){
			jQuery("#setting-production_testrecords").find('td').filter(function(){
				return jQuery(this).index() === thIndex;
			}).sortElements(function(a, b){
				return jQuery.text([a]) > jQuery.text([b]) ?
					inverse ? -1 : 1
					: inverse ? 1 : -1;
			}, function(){
				return this.parentNode; 
			});
			inverse = !inverse;
		});
	});
	jQuery("#sort-action-record,#sort-action-assignee,#sort-action-status,#sort-action-workflowID,#sort-action-processID").each(function(){
		var th = jQuery(this),
			thIndex = th.index(),
			inverse = false;		
		th.click(function(){
			jQuery("#lineChart_production_testrecords").find('td').filter(function(){
				return jQuery(this).index() === thIndex;
			}).sortElements(function(a, b){
				return jQuery.text([a]) > jQuery.text([b]) ?
					inverse ? -1 : 1
					: inverse ? 1 : -1;
			}, function(){
				return this.parentNode; 
			});
			inverse = !inverse;
		});
	});
	
	//*******Table Length*********//
	
	
	//******Line Chart******//
	jQuery("#hideButton").on('click',function(event){
		jQuery("#lineChart_production_testrecords").toggle('show');
	});
	jQuery("#hideButton_testrecords").on('click',function(event){
		jQuery("#setting-production_testrecords").toggle('show');
	});
	
	jQuery("#hideButton_testrecords").hide();
	jQuery("#hideButton").hide();
	jQuery("#attributesFilter").hide();
	jQuery("#refreshLine").hide();
	jQuery("#buttons").hide();
	jQuery("#attributes2Header").hide();
	jQuery("#attributes2Content").hide();
	jQuery(".separator").hide();
	jQuery(".export2excel").hide();
	jQuery("#setting-production_testrecords").hide();
	jQuery("#lineChart_production_testrecords").hide();
	
	jQuery("#lineChart_attribute1_select").change(function(){
		document.getElementById("loader").style.display = "block";
		deleteHistory("lineChart_attribute2_select");
		lineChart_attribute1_select();
		google.charts.setOnLoadCallback(drawLineChart);
		google.charts.setOnLoadCallback(drawLine2Chart);
		google.charts.setOnLoadCallback(drawLine3Chart);
		document.getElementById("loader").style.display = "none";
	});
	jQuery("#lineChart_attribute2_select").change(function(){
		document.getElementById("loader").style.display = "block";
		google.charts.setOnLoadCallback(drawLineChart);
		google.charts.setOnLoadCallback(drawLine2Chart);
		google.charts.setOnLoadCallback(drawLine3Chart);
		document.getElementById("loader").style.display = "none";
	});
	
	function lineChart_pn_select(partno)
	{
		if(partno)
		{
			data={
				action : 'get_testitems_of_partno',
				partno : partno
			};
			jQuery.ajax(
			{
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					if(response)
					{
						var testitems = JSON.parse(response);
						if(testitems.length!=0)
						{
							jQuery("#lineChart_testitem_select").append(
										  "<option selected ='selected'></option>");
							for(var i=0;i< testitems.length;i++){
							jQuery("#lineChart_testitem_select").append(
											  "<option >"+testitems[i]+"</option>"
								
							);				
						}
						}
					}
				}
				
			});
		}
		//getTestResultInfo();
	}
	function lineChart_testitem_select()
	{
		deleteHistory("lineChart_attribute1_select");
		var partno = document.getElementById("setting-partno_select");
		//var partno_selected = partno.options[partno.selectedIndex].text;
		var partno_selected = jQuery("#setting-partno_select").val();
		partno_selected =  partnoInfo2Part(partno_selected);
		var testitem = document.getElementById("setting-testitem_select");
		var testitem_sel ;
		if(testitem.options.length!=0)
		{
			testitem_sel = testitem.options[testitem.selectedIndex].text;
		}
		var startdate = jQuery( "#setting-start-date" ).val();
		var enddate = jQuery( "#setting-end-date" ).val();
		if(testitem_sel)
		{
			data={
				action : 'get_attribute1_of_testitem',
				partno_selected: partno_selected,
				testitem_sel : testitem_sel,
				startdate: startdate,
				enddate: enddate
			};
			jQuery.ajax(
			{
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					if(response)
					{
						var testitems = JSON.parse(response);
						if(testitems.length!=0)
						{
							document.getElementById("loader").style.display = "block";
							jQuery("#lineChart_attribute1_select").append(
										  "<option selected ='selected'></option>");
							for(var i=0;i< testitems.length;i++){
							jQuery("#lineChart_attribute1_select").append(
											  "<option >"+testitems[i]+"</option>"
								
							);				
							}
							document.getElementById("loader").style.display = "none";
						}
					}
				}
				
			});
		}
		//getTestResultInfo();
	}
	function lineChart_attribute1_select()
	{
		var partno = document.getElementById("setting-partno_select");
		//var partno_selected = partno.options[partno.selectedIndex].text;
		var partno_selected = jQuery( "#setting-partno_select" ).val();
		partno_selected = partnoInfo2Part(partno_selected);
		var testitem = document.getElementById("setting-testitem_select");
		var testitem_sel = testitem.options[testitem.selectedIndex].text;
		var attribute1 = document.getElementById("lineChart_attribute1_select");
		var attribute1_sel = attribute1.options[attribute1.selectedIndex].text;
		if(testitem_sel)
		{
			data={
				action : 'get_attribute2info_of_testitem',
				partno_selected: partno_selected,
				testitem_sel : testitem_sel,
				attribute1_sel: attribute1_sel
			};
			jQuery.ajax(
			{
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					if(response)
					{
						var testitems = JSON.parse(response);
						if(testitems.length!=0)
						{
							document.getElementById("loader").style.display = "block";
							jQuery("#attributes2Header").toggle('show');
							jQuery("#attributes2Content").toggle('show');
							jQuery("#lineChart_attribute2_select").append(
										  "<option selected ='selected'></option>");
							for(var i=0;i< testitems.length;i++){
								jQuery("#lineChart_attribute2_select").append("<option >"+testitems[i]+"</option>");				
							}
							document.getElementById("loader").style.display = "none";
						}
					}
				}
				
			});
		}
		getTestResultInfo();
	}
	var pages = 0;
	function getTestResultInfo(){
		deleteTableData("lineChart_production_testrecords");
		
		var partno_selected = "";
		var testitem_sel= "";
		var attribute1_sel= "";
		var attribute2_sel= "";
		var results = "";
		var partno = jQuery("#setting-partno_select").val();
		partno = partnoInfo2Part(partno);
		if(partno)
		{
			partno_selected =partno;
		}
		var testitem = document.getElementById("setting-testitem_select");
		if(testitem.length!=0){
			testitem_sel = testitem.options[testitem.selectedIndex].text;
		}
		var attribute1 = document.getElementById("lineChart_attribute1_select");
		if(attribute1.length!=0){
			attribute1_sel = attribute1.options[attribute1.selectedIndex].text;
		}
		var attribute2 = document.getElementById("lineChart_attribute2_select");
		if(attribute2.length!=0){
			attribute2_sel = attribute2.options[attribute2.selectedIndex].text;
		}
		var startdate = jQuery( "#setting-start-date" ).val();
		var enddate = jQuery( "#setting-end-date" ).val();
		if(partno_selected!=""&&partno_selected!=null&&testitem_sel!=""&&testitem_sel!=null&&attribute1_sel!=""&&attribute1_sel!=null&&attribute2_sel!=""&&attribute2_sel!=null&&attribute2_sel!="null")
		{
			data={
				action : 'get_testresultdata',
				partno_selected: partno_selected,
				testitem_sel : testitem_sel,
				startdate: startdate,
				enddate: enddate,
				attribute1_sel: attribute1_sel,
				attribute2_sel: attribute2_sel
			};
			jQuery.ajax(
			{
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					if(response)
					{
						results = JSON.parse(response);
						if(results.length!=0)
						{
							for(var i=0;i< results.length;i++){	
								var result = results[i].split("|");
								jQuery("#lineChart_production_testrecords_body").append(
												  "<tr><td>"+result[0]
												  +"</td><td>"+result[2]
												  +"</td><td>"+result[1]
												  +"</td><td>"+result[3]
												  +"</td><td>"+result[4]
												  +"</td></tr>"
								);						
							}
							if(pages==0)
							{
								jQuery("table.wp-list-table").DataTable({"lengthMenu": [[-1,10, 25, 50], ["All",10, 25, 50]]} );
								jQuery("#lineChart_production_testrecords").show();
								jQuery("#setting-production_testrecords").show();
								pages = 1;
								
							}
						}
						
					}
					
				}
			});
			return results;
		}
		else if(partno_selected!=""&&partno_selected!=null&&testitem_sel!=""&&testitem_sel!=null&&attribute1_sel!=""&&attribute1_sel!=null)
		{
			data={
				action : 'get_testresultdata',
				partno_selected: partno_selected,
				testitem_sel : testitem_sel,
				startdate: startdate,
				enddate: enddate,
				attribute1_sel: attribute1_sel
			};
			jQuery.ajax(
			{
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					if(response)
					{
						results = JSON.parse(response);
						if(results.length!=0)
						{
							for(var i=0;i< results.length;i++){	
								var result = results[i].split("|");
								jQuery("#lineChart_production_testrecords_body").append(
												  "<tr><td>"+result[0]
												  +"</td><td>"+result[2]
												  +"</td><td>"+result[1]
												  +"</td><td>"+result[3]
												  +"</td><td>"+result[4]
												  +"</td></tr>"
								);						
							}				
						}
						if(pages==0)
						{
							jQuery("table.wp-list-table").DataTable({"lengthMenu": [[-1,10, 25, 50], ["All",10, 25, 50]]} );
							jQuery("#lineChart_production_testrecords").show();
							jQuery("#setting-production_testrecords").show();
							pages = 1;
						}
					}
				}
			});
				return results;
		}
		else if(partno_selected!=""&&partno_selected!=null&&testitem_sel!=""&&testitem_sel!=null)
		{
			data={
				action : 'get_testresultdata',
				partno_selected: partno_selected,
				testitem_sel : testitem_sel,
				startdate: startdate,
				enddate: enddate
			};
			jQuery.ajax(
			{
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					if(response)
					{
						results = JSON.parse(response);
						if(results.length!=0)
						{
							for(var i=0;i< results.length;i++){	
								var result = results[i].split("|");
								jQuery("#lineChart_production_testrecords_body").append(
												  "<tr><td>"+result[0]
												  +"</td><td>"+result[2]
												  +"</td><td>"+result[1]
												  +"</td><td>"+result[3]
												  +"</td><td>"+result[4]
												  +"</td></tr>"
								);
							}
							if(pages==0)
							{
								jQuery("table.wp-list-table").DataTable({"lengthMenu": [[-1, 10, 25, 50], ["All",10, 25, 50 ]]} );
								jQuery("#lineChart_production_testrecords").show();
								jQuery("#setting-production_testrecords").show();
								pages = 1;
							}
						}
					
					}
				}
			});
				return results;
		}
	}
	
	function getTestResultStatistics()
	{
		var partno_selected = "";
		var testitem_sel= "";
		var attribute1_sel= "";
		var attribute2_sel= "";
		var results = "";
		var partno = jQuery("#setting-partno_select").val();
		partno = partnoInfo2Part(partno);
		if(partno){
			partno_selected =partno;
		}
		var testitem = document.getElementById("setting-testitem_select");
		if(testitem.length!=0){
			testitem_sel = testitem.options[testitem.selectedIndex].text;
		}
		var attribute1 = document.getElementById("lineChart_attribute1_select");
		if(attribute1.length!=0){
			attribute1_sel = attribute1.options[attribute1.selectedIndex].text;
		}
		var attribute2 = document.getElementById("lineChart_attribute2_select");
		if(attribute2.length!=0){
			attribute2_sel = attribute2.options[attribute2.selectedIndex].text;
		}
		var startdate = jQuery( "#setting-start-date" ).val();
		var enddate = jQuery( "#setting-end-date" ).val();
		data={
				action : 'get_testresultStatisticsSummary',
				partno_selected: partno_selected,
				testitem_sel : testitem_sel,
				startdate: startdate,
				enddate: enddate,
				attribute1_sel: attribute1_sel,
				attribute2_sel: attribute2_sel
			};
			jQuery.ajax(
			{
				type: "POST",
			    url: ajaxurl,
			    data: data,
			    async: false,
				success: function(response){
					if(response){
						results = JSON.parse(response);
					}
				}
			});
			return results;
	}
	function AddNamespaceHandler(){
		var svg = jQuery('#linechart_production_result svg');
		svg.attr("xmlns", "http://www.w3.org/2000/svg");
		svg.css('overflow','visible');
	}
	function drawLineChart() {
		  var rawData = getTestResultInfo();
		  var result= [];
		  if(rawData)
			{
				result = [];
				 for(var i=0;i< rawData.length;i++){	
					var div = rawData[i].split("|");
					//alert(div[0]);
					//alert(new Date(div[0]));
				 result.push([new Date(div[0]),parseFloat(div[3]),parseFloat(div[1]),parseFloat(div[2])]);		
				}
			}
			var testitem = document.getElementById("setting-testitem_select");
		if(testitem.length!=0){
			testitem_sel = testitem.options[testitem.selectedIndex].text;
		}
		var attribute1 = document.getElementById("lineChart_attribute1_select");
		if(attribute1.length!=0){
			attribute1_sel = attribute1.options[attribute1.selectedIndex].text;
		}
		var attribute2 = document.getElementById("lineChart_attribute2_select");
		if(attribute2.length!=0){
			attribute2_sel = attribute2.options[attribute2.selectedIndex].text;
		}
		  var data = new google.visualization.DataTable();
		  data.addColumn('datetime', 'Date');
		  data.addColumn('number', 'Upper Limit');
		  data.addColumn('number', 'Data');
		  data.addColumn('number', 'Lower Limit');
		  data.addRows(result);
		  var options = {
			title: testitem_sel,
			subtitle: '',
			width: 1000,
			height: 500,
			lineWidth: 3,
			hAxis:{title:'Date', },
			vAxis:{title:attribute1_sel+' - '+attribute2_sel},
			explorer: { maxZoomIn: .5 , maxZoomOut: 8 },
			series: {
				0: { lineWidth: 2,pointSize: 0,},
				1: { color: '#6f9654',lineWidth: 3,pointSize: 5,},
				2: { lineWidth: 2,pointSize: 0, },
			},
			
		  };
		  var chart = new google.visualization.LineChart(document.getElementById('linechart_production_result'));
		   //google.visualization.events.addListener(chart, 'ready', AddNamespaceHandler); 
		   chart.draw(data, options);
    }
	function drawLine2Chart() {
		  var rawData = getTestResultInfo();
		  var result= [];
		  if(rawData)
			{
				result = [];
				 for(var i=0;i< rawData.length;i++){	
					var div = rawData[i].split("|");
				 //result.push([new Date(div[0]),parseFloat(div[3]),parseFloat(div[1]),parseFloat(div[2])]);
				 result.push([parseInt(i),parseFloat(div[3]),parseFloat(div[1]),parseFloat(div[2])]);
				}
			}
		var testitem = document.getElementById("setting-testitem_select");
		if(testitem.length!=0){
			testitem_sel = testitem.options[testitem.selectedIndex].text;
		}
		var attribute1 = document.getElementById("lineChart_attribute1_select");
		if(attribute1.length!=0){
			attribute1_sel = attribute1.options[attribute1.selectedIndex].text;
		}
		var attribute2 = document.getElementById("lineChart_attribute2_select");
		if(attribute2.length!=0){
			attribute2_sel = attribute2.options[attribute2.selectedIndex].text;
		}
		  var data = new google.visualization.DataTable();
		    //data.addColumn('datetime', 'Date');
			data.addColumn('number', 'Index');
		  data.addColumn('number', 'Upper Limit');
		  data.addColumn('number', 'Data');
		  data.addColumn('number', 'Lower Limit');
		  data.addRows(result);
		  var options = {
			title: testitem_sel,
			subtitle: '',
			width: 1000,
			height: 500,
			lineWidth: 3,
			hAxis:{title:'No. of Test', },
			vAxis:{title:attribute1_sel+' - '+attribute2_sel},
			explorer: { maxZoomIn: .5 , maxZoomOut: 8 },
			series: {
				0: { lineWidth: 2,pointSize: 0, },
				1: { lineWidth: 3,pointSize: 5, color: '#6f9654'},
				2: { lineWidth: 2,pointSize: 0,},
			}
		  };

		  var chart = new google.visualization.LineChart(document.getElementById('linechart2_production_result'));
		   //google.visualization.events.addListener(chart, 'ready', AddNamespaceHandler); 
		   chart.draw(data, options);
    }
	
	function drawLine3Chart() {
		  var rawData = getTestResultStatistics();
		  var result= [];
		  if(rawData)
			{
				var maxnumber = 0;
				var minnumber = 0;
				result = [];
				 for(var i=0;i< rawData.length;i++){	
					var div = rawData[i].split("|");
					if(parseFloat(div[0])>maxnumber)
					{
						maxnumber = parseFloat(div[0]);
					}
					if(parseFloat(div[0])<minnumber)
					{
						minnumber = parseFloat(div[0]);
					}
					 result.push([parseFloat(div[0]),parseFloat(div[1])]);
				}
			}
		  var data = new google.visualization.DataTable();
			data.addColumn('number', 'Data');
		  data.addColumn('number', 'Times');
		  data.addRows(result);
		  var options = {
			title: 'Frequencies of Data(Run Time/Data)',
			subtitle: '',
			width: 1000,
			height: 500,
			hAxis:{
				title:'Data', 
				viewWindow:{
					min:[minnumber/2],
					max:[maxnumber*2]
					}
				},
			vAxis:{title:'Times'},
			legend: { position: "none"},
		  };

		  var chart = new google.visualization.ColumnChart(document.getElementById('linechart3_production_result'));
		   google.visualization.events.addListener(chart, 'ready', AddNamespaceHandler); 
		   chart.draw(data, options);
    }
	//**********Generate to PDF**************
	//var click="return xepOnline.Formatter.Format('JSFiddle', {render:'download', srctype:'svg'})";
	//jQuery('#buttons').append('<button style="width:100px;height:30px;" onclick="'+ click +'">Generate PDF</button>');
	
	jQuery("#btnExport").on('click',function(event){
		 window.open('data:application/vnd.ms-excel,' + $('#table2excel').html());
    event.preventDefault();
	});
	
	
});
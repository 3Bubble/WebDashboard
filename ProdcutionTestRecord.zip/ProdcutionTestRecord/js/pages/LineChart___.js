jQuery(document).ready(function(){
	jQuery( "#lineChart-start-date" ).datepicker({
		autoSize: true,
		onSelect: function(dateText, inst) {
			
		}
	});
	jQuery( "#lineChart-end-date" ).datepicker({
		autoSize: true,
		onSelect: function(dateText, inst) {
			
		}
	});
	jQuery("#lineChart_pn_select").change(function(){
		data={
			action : 'getPartNoList'
		};
		jQuery.ajax(
		{
			type: "POST",
			url: ajaxurl,
			data: data,
			async: false,
			success: function(response){
				if(response)
				{
					alert("testing");
				}
			}
			
		});
	});
});
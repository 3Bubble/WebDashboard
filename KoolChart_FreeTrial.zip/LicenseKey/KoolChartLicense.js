// -----------------------------------------------------------------------------
// KoolChart License Key 
//
// Product Name : KoolChart v4.0
// License Type : Premium License (Trial)
// Product No : ED11-2752-337B-C8CV
// Authenticated Server : *
// Expiration Date : 2016/08/01
//
var KoolChartLicense = "3c7c341b2ac0b5722b42a303fd716938a14feeecf83738effcbef3b9698ba64f:3700350b32434e3a4f4220504c2056563a4332382e43302d2042503756333a334b2d35322d35503752322d2d34312e3130442d45453a564c41204c312030452f4c383a30742f203643313a303232303a31453620302a353a334831";